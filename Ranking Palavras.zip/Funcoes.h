
int contador_de_palavras (char* str, int limite);
void formatador_de_texto (char* str,int limite);
void separador_de_palavras(char* str,int limite);
char** lista_de_palavras (char* str,int limite);
